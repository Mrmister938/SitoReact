import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Layout } from "./components/Layout";
import Dashboard from "./pages/Dashboard";
import LiveCalls from "./pages/LiveCalls";
import CallHistory from "./pages/CallHistory";
import AudioPlayer from "./pages/AudioPlayer";
import Insights from "./pages/Insights";
import KnowledgeBase from "./pages/KnowledgeBase";
import Configuration from "./pages/Configuration";
import Integrations from "./pages/Integrations";
import Automations from "./pages/Automations";
import Reports from "./pages/Reports";
import Team from "./pages/Team";
import Account from "./pages/Account";
import Support from "./pages/Support";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<Dashboard />} />
            <Route path="/live-calls" element={<LiveCalls />} />
            <Route path="/history" element={<CallHistory />} />
            <Route path="/audio" element={<AudioPlayer />} />
            <Route path="/insights" element={<Insights />} />
            <Route path="/knowledge" element={<KnowledgeBase />} />
            <Route path="/config" element={<Configuration />} />
            <Route path="/integrations" element={<Integrations />} />
            <Route path="/automations" element={<Automations />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="/team" element={<Team />} />
            <Route path="/account" element={<Account />} />
            <Route path="/support" element={<Support />} />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
