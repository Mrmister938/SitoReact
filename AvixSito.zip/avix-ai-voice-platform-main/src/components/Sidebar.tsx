import { NavLink } from "@/components/NavLink";
import {
  LayoutDashboard,
  Phone,
  History,
  PlayCircle,
  TrendingUp,
  BookOpen,
  Settings,
  Plug,
  Workflow,
  FileText,
  Users,
  UserCog,
  HelpCircle,
  LogOut,
  Bot,
} from "lucide-react";
import {
  Sidebar as SidebarUI,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";

const menuItems = [
  { title: "Dashboard", url: "/", icon: LayoutDashboard },
  { title: "Chiamate Live", url: "/live-calls", icon: Phone },
  { title: "Storico Chiamate", url: "/history", icon: History },
  { title: "Audio Player", url: "/audio", icon: PlayCircle },
  { title: "AI Insights", url: "/insights", icon: TrendingUp },
  { title: "Knowledge Base", url: "/knowledge", icon: BookOpen },
  { title: "Configurazione", url: "/config", icon: Settings },
  { title: "Integrazioni", url: "/integrations", icon: Plug },
  { title: "Automazioni", url: "/automations", icon: Workflow },
  { title: "Report", url: "/reports", icon: FileText },
  { title: "Team", url: "/team", icon: Users },
  { title: "Account", url: "/account", icon: UserCog },
  { title: "Supporto", url: "/support", icon: HelpCircle },
];

export function Sidebar() {
  const { open } = useSidebar();

  return (
    <SidebarUI className={open ? "w-64" : "w-16"}>
      <SidebarContent>
        <div className="p-4 border-b border-border">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-gradient-primary flex items-center justify-center">
              <Bot className="h-5 w-5 text-primary-foreground" />
            </div>
            {open && (
              <span className="font-bold text-lg bg-gradient-primary bg-clip-text text-transparent">
                Avix-AI
              </span>
            )}
          </div>
        </div>

        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink
                      to={item.url}
                      end
                      className="hover:bg-sidebar-accent transition-colors"
                      activeClassName="bg-sidebar-accent text-primary font-medium"
                    >
                      <item.icon className="h-5 w-5" />
                      {open && <span>{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
              
              <SidebarMenuItem>
                <SidebarMenuButton className="hover:bg-destructive/10 text-destructive">
                  <LogOut className="h-5 w-5" />
                  {open && <span>Logout</span>}
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </SidebarUI>
  );
}
