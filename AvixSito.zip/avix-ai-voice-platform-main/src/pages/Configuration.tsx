import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Bot, Volume2, MessageSquare, Workflow } from "lucide-react";

export default function Configuration() {
  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold">Configurazione Assistente</h1>
        <p className="text-muted-foreground">Personalizza il comportamento dell'AI</p>
      </div>

      <Tabs defaultValue="identity" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="identity" className="gap-2">
            <Bot className="h-4 w-4" />
            Identità
          </TabsTrigger>
          <TabsTrigger value="voice" className="gap-2">
            <Volume2 className="h-4 w-4" />
            Voce
          </TabsTrigger>
          <TabsTrigger value="behavior" className="gap-2">
            <MessageSquare className="h-4 w-4" />
            Comportamento
          </TabsTrigger>
          <TabsTrigger value="flows" className="gap-2">
            <Workflow className="h-4 w-4" />
            Flussi
          </TabsTrigger>
        </TabsList>

        <TabsContent value="identity" className="space-y-6 mt-6">
          <Card className="gradient-card border-border">
            <CardHeader>
              <CardTitle>Identità & Persona</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Nome Assistente</Label>
                <Input defaultValue="Avix" className="bg-muted/30" />
              </div>
              <div className="space-y-2">
                <Label>Tono di Comunicazione</Label>
                <Input defaultValue="Professionale e cordiale" className="bg-muted/30" />
              </div>
              <div className="space-y-2">
                <Label>System Prompt</Label>
                <Textarea
                  defaultValue="Sei Avix, un assistente vocale intelligente per [azienda]. Il tuo obiettivo è aiutare i clienti in modo efficiente e professionale..."
                  className="min-h-[150px] bg-muted/30 font-mono text-sm"
                />
                <p className="text-xs text-muted-foreground">Definisci la personalità e le istruzioni base dell'AI</p>
              </div>
              <Button className="bg-primary hover:bg-primary/90">Salva Modifiche</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="voice" className="space-y-6 mt-6">
          <Card className="gradient-card border-border">
            <CardHeader>
              <CardTitle>Impostazioni Voce</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <Label>Voce TTS</Label>
                <div className="grid grid-cols-2 gap-3">
                  {["Alloy", "Echo", "Fable", "Nova", "Onyx", "Shimmer"].map((voice) => (
                    <Button
                      key={voice}
                      variant="outline"
                      className="justify-start bg-muted/30 hover:bg-primary/20 hover:border-primary"
                    >
                      {voice}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label>Velocità Parlato</Label>
                  <span className="text-sm text-muted-foreground">1.0x</span>
                </div>
                <Slider defaultValue={[50]} max={100} step={1} />
              </div>

              <div className="space-y-3">
                <Label>Emozione</Label>
                <div className="flex flex-wrap gap-2">
                  {["Neutrale", "Felice", "Professionale", "Empatica", "Energica"].map((emotion) => (
                    <Button key={emotion} size="sm" variant="outline" className="bg-muted/30">
                      {emotion}
                    </Button>
                  ))}
                </div>
              </div>

              <Button className="bg-primary hover:bg-primary/90">Salva Configurazione</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="behavior" className="space-y-6 mt-6">
          <Card className="gradient-card border-border">
            <CardHeader>
              <CardTitle>Comportamento Telefonico</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label>Attesa Prima di Parlare</Label>
                  <span className="text-sm text-muted-foreground">800ms</span>
                </div>
                <Slider defaultValue={[40]} max={100} step={1} />
              </div>

              <div className="space-y-2">
                <Label>Frase Iniziale</Label>
                <Input
                  defaultValue="Buongiorno! Sono Avix, il tuo assistente virtuale. Come posso aiutarti?"
                  className="bg-muted/30"
                />
              </div>

              <div className="space-y-2">
                <Label>Frase Finale</Label>
                <Input
                  defaultValue="È stato un piacere aiutarti. Buona giornata!"
                  className="bg-muted/30"
                />
              </div>

              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                <div>
                  <Label>Gestione Fuori Orario</Label>
                  <p className="text-xs text-muted-foreground mt-1">Rispondi automaticamente fuori orario</p>
                </div>
                <Switch />
              </div>

              <div className="space-y-2">
                <Label>Messaggio Fuori Orario</Label>
                <Textarea
                  defaultValue="Mi dispiace, al momento siamo chiusi. I nostri orari sono..."
                  className="bg-muted/30"
                />
              </div>

              <Button className="bg-primary hover:bg-primary/90">Salva Comportamento</Button>
            </CardContent>
          </Card>

          <Card className="gradient-card border-border">
            <CardHeader>
              <CardTitle>Regole Escalation</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Numero Operatore</Label>
                <Input placeholder="+39 02 1234 5678" className="bg-muted/30" />
              </div>

              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                <div>
                  <Label>Fallback Automatico</Label>
                  <p className="text-xs text-muted-foreground mt-1">Trasferisci se l'AI non può gestire</p>
                </div>
                <Switch defaultChecked />
              </div>

              <Button className="bg-primary hover:bg-primary/90">Salva Regole</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="flows" className="space-y-6 mt-6">
          <Card className="gradient-card border-primary/30">
            <CardHeader>
              <CardTitle>Editor Flussi Conversazionali</CardTitle>
              <p className="text-sm text-muted-foreground">Editor visuale in arrivo</p>
            </CardHeader>
            <CardContent>
              <div className="h-96 bg-muted/30 rounded-lg border-2 border-dashed border-border flex items-center justify-center">
                <div className="text-center space-y-2">
                  <Workflow className="h-16 w-16 mx-auto text-muted-foreground" />
                  <p className="text-lg font-medium">Editor Flussi</p>
                  <p className="text-sm text-muted-foreground">Trascina e rilascia per creare flussi conversazionali</p>
                  <Button className="mt-4 bg-primary hover:bg-primary/90">Crea Nuovo Flusso</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
