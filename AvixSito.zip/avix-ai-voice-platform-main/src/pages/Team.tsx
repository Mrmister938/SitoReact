import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Plus, Search, Mail, Shield, Eye, Edit, Trash2 } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const teamMembers = [
  { id: 1, name: "Marco Rossi", email: "marco.rossi@avix.ai", role: "Admin", status: "active", lastActive: "2 min fa" },
  { id: 2, name: "Laura Bianchi", email: "laura.bianchi@avix.ai", role: "Analista", status: "active", lastActive: "1 ora fa" },
  { id: 3, name: "Giuseppe Verdi", email: "giuseppe.verdi@avix.ai", role: "Viewer", status: "active", lastActive: "3 ore fa" },
  { id: 4, name: "Sofia Romano", email: "sofia.romano@avix.ai", role: "Tecnico", status: "inactive", lastActive: "2 giorni fa" },
];

const getRoleBadge = (role: string) => {
  const variants = {
    Admin: "bg-primary/20 text-primary border-primary",
    Analista: "bg-info/20 text-info border-info",
    Viewer: "bg-muted/30 text-muted-foreground border-border",
    Tecnico: "bg-secondary/20 text-secondary border-secondary",
  };
  return <Badge className={variants[role as keyof typeof variants] || ""}>{role}</Badge>;
};

export default function Team() {
  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Gestione Team</h1>
          <p className="text-muted-foreground">Utenti e permessi del tenant</p>
        </div>
        <Button className="bg-primary hover:bg-primary/90">
          <Plus className="h-4 w-4 mr-2" />
          Invita Membro
        </Button>
      </div>

      <Card className="gradient-card border-border">
        <CardHeader>
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Cerca per nome o email..." className="pl-10 bg-muted/30" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Utente</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Ruolo</TableHead>
                <TableHead>Stato</TableHead>
                <TableHead>Ultimo Accesso</TableHead>
                <TableHead className="text-right">Azioni</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {teamMembers.map((member) => (
                <TableRow key={member.id} className="hover:bg-muted/30">
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Avatar className="h-10 w-10 border-2 border-primary/20">
                        <AvatarFallback className="bg-primary/10 text-primary">
                          {member.name.split(" ").map(n => n[0]).join("")}
                        </AvatarFallback>
                      </Avatar>
                      <span className="font-medium">{member.name}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      {member.email}
                    </div>
                  </TableCell>
                  <TableCell>{getRoleBadge(member.role)}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={member.status === "active" ? "border-success text-success" : "border-muted-foreground text-muted-foreground"}>
                      {member.status === "active" ? "Attivo" : "Inattivo"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground">{member.lastActive}</TableCell>
                  <TableCell>
                    <div className="flex items-center justify-end gap-1">
                      <Button size="sm" variant="ghost">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="ghost">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Roles & Permissions */}
      <Card className="gradient-card border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-primary" />
            Ruoli e Permessi
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { role: "Admin", permissions: ["Tutti i permessi", "Gestione team", "Fatturazione"] },
              { role: "Analista", permissions: ["Visualizza analytics", "Export dati", "Report"] },
              { role: "Viewer", permissions: ["Solo lettura", "Dashboard base"] },
              { role: "Tecnico", permissions: ["Configurazione", "Integrazioni", "Test"] },
            ].map((role) => (
              <Card key={role.role} className="bg-muted/30 border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm">{role.role}</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-1 text-xs text-muted-foreground">
                    {role.permissions.map((perm, idx) => (
                      <li key={idx} className="flex items-center gap-2">
                        <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                        {perm}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
