import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, Users, Clock, MessageSquare } from "lucide-react";
import { BarChart, Bar, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from "recharts";

const topicData = [
  { topic: "Prenotazioni", count: 145 },
  { topic: "Info Servizi", count: 98 },
  { topic: "Reclami", count: 23 },
  { topic: "Cancellazioni", count: 34 },
  { topic: "Supporto Tecnico", count: 67 },
];

const sentimentData = [
  { sentiment: "Positivo", value: 75 },
  { sentiment: "Neutro", value: 20 },
  { sentiment: "Negativo", value: 5 },
];

const performanceData = [
  { metric: "Risoluzione", value: 85 },
  { metric: "Velocità", value: 92 },
  { metric: "Accuratezza", value: 88 },
  { metric: "Soddisfazione", value: 90 },
  { metric: "Efficienza", value: 87 },
];

export default function Insights() {
  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold">AI Insights</h1>
        <p className="text-muted-foreground">Analytics avanzate e intelligence</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="gradient-card border-primary/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Topic Principali</CardTitle>
            <MessageSquare className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">5</div>
            <p className="text-xs text-muted-foreground mt-1">Categorie rilevate</p>
          </CardContent>
        </Card>

        <Card className="gradient-card border-success/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Sentiment</CardTitle>
            <TrendingUp className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">75%</div>
            <p className="text-xs text-muted-foreground mt-1">Positivo</p>
          </CardContent>
        </Card>

        <Card className="gradient-card border-info/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Tempo Medio</CardTitle>
            <Clock className="h-4 w-4 text-info" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-info">2m 34s</div>
            <p className="text-xs text-muted-foreground mt-1">Per risoluzione</p>
          </CardContent>
        </Card>

        <Card className="gradient-card border-warning/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Utenti Unici</CardTitle>
            <Users className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-warning">1,234</div>
            <p className="text-xs text-muted-foreground mt-1">Questo mese</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="gradient-card border-border">
          <CardHeader>
            <CardTitle>Topic Clustering</CardTitle>
            <p className="text-sm text-muted-foreground">Richieste più comuni</p>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={topicData}>
                <XAxis dataKey="topic" stroke="hsl(var(--muted-foreground))" />
                <YAxis stroke="hsl(var(--muted-foreground))" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                  }}
                />
                <Bar dataKey="count" fill="hsl(190 100% 50%)" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="gradient-card border-border">
          <CardHeader>
            <CardTitle>Performance AI</CardTitle>
            <p className="text-sm text-muted-foreground">Metriche chiave</p>
          </CardHeader>
          <CardContent className="flex items-center justify-center">
            <ResponsiveContainer width="100%" height={300}>
              <RadarChart data={performanceData}>
                <PolarGrid stroke="hsl(var(--border))" />
                <PolarAngleAxis dataKey="metric" stroke="hsl(var(--muted-foreground))" />
                <PolarRadiusAxis stroke="hsl(var(--muted-foreground))" />
                <Radar name="Performance" dataKey="value" stroke="hsl(190 100% 50%)" fill="hsl(190 100% 50%)" fillOpacity={0.3} />
              </RadarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Sentiment Analysis */}
      <Card className="gradient-card border-border">
        <CardHeader>
          <CardTitle>Analisi Sentiment</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {sentimentData.map((item) => (
              <div key={item.sentiment} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">{item.sentiment}</span>
                  <span className="text-sm text-muted-foreground">{item.value}%</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${
                      item.sentiment === "Positivo"
                        ? "bg-success"
                        : item.sentiment === "Neutro"
                        ? "bg-info"
                        : "bg-destructive"
                    }`}
                    style={{ width: `${item.value}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Insights Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="gradient-card border-success/30">
          <CardHeader>
            <CardTitle className="text-sm">💡 Insight</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm">Le prenotazioni sono aumentate del 23% nelle ultime 2 settimane. Ottimo lavoro!</p>
          </CardContent>
        </Card>

        <Card className="gradient-card border-warning/30">
          <CardHeader>
            <CardTitle className="text-sm">⚠️ Attenzione</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm">I reclami sono aumentati del 15%. Considera di aggiornare la knowledge base.</p>
          </CardContent>
        </Card>

        <Card className="gradient-card border-info/30">
          <CardHeader>
            <CardTitle className="text-sm">📈 Raccomandazione</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm">Le chiamate tra le 14:00-16:00 hanno il tasso di successo più alto. Ottimizza per questi orari.</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
