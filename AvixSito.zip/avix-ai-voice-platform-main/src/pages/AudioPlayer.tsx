import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Play, Pause, Download, Volume2 } from "lucide-react";
import { Slider } from "@/components/ui/slider";

export default function AudioPlayer() {
  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold">Audio Player</h1>
        <p className="text-muted-foreground">Riproduci e scarica le registrazioni</p>
      </div>

      <Card className="gradient-card border-primary/30">
        <CardHeader>
          <CardTitle>Registrazione Chiamata</CardTitle>
          <p className="text-sm text-muted-foreground">+39 345 678 9012 • 15 Gen 2025 14:23</p>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Waveform visualization mockup */}
          <div className="h-32 bg-muted/30 rounded-lg flex items-center justify-center relative overflow-hidden">
            <div className="flex items-center gap-1 h-full w-full px-4">
              {[...Array(100)].map((_, i) => (
                <div
                  key={i}
                  className="flex-1 bg-primary rounded-full"
                  style={{
                    height: `${Math.random() * 80 + 20}%`,
                    opacity: i < 40 ? 1 : 0.3,
                  }}
                />
              ))}
            </div>
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-primary/10 to-transparent animate-pulse" />
          </div>

          {/* Controls */}
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <Button size="lg" className="h-12 w-12 rounded-full bg-primary hover:bg-primary/90">
                <Play className="h-6 w-6" />
              </Button>
              <div className="flex-1">
                <Slider defaultValue={[40]} max={100} step={1} className="cursor-pointer" />
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>1:23</span>
                  <span>3:45</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-4 p-4 bg-muted/30 rounded-lg">
              <Volume2 className="h-5 w-5 text-muted-foreground" />
              <Slider defaultValue={[70]} max={100} step={1} className="flex-1" />
            </div>
          </div>

          {/* Channels */}
          <div className="grid grid-cols-2 gap-4">
            <Card className="bg-muted/30 border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Canale Utente</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-20 bg-secondary/20 rounded flex items-center justify-center">
                  <p className="text-xs text-muted-foreground">Audio separato disponibile</p>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-muted/30 border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Canale AI</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-20 bg-primary/20 rounded flex items-center justify-center">
                  <p className="text-xs text-muted-foreground">Audio separato disponibile</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Download */}
          <div className="flex gap-2">
            <Button variant="outline" className="flex-1">
              <Download className="h-4 w-4 mr-2" />
              Download MP3
            </Button>
            <Button variant="outline" className="flex-1">
              <Download className="h-4 w-4 mr-2" />
              Download WAV
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Transcript */}
      <Card className="gradient-card border-border">
        <CardHeader>
          <CardTitle>Trascrizione Accoppiata</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex gap-3">
              <div className="text-xs text-muted-foreground w-16">0:05</div>
              <div className="flex-1 p-3 bg-primary/10 border border-primary/20 rounded-lg">
                <p className="text-xs font-medium text-primary mb-1">AI</p>
                <p className="text-sm">Buongiorno! Sono l'assistente Avix. Come posso aiutarti?</p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="text-xs text-muted-foreground w-16">0:12</div>
              <div className="flex-1 p-3 bg-secondary/10 border border-secondary/20 rounded-lg">
                <p className="text-xs font-medium text-secondary mb-1">Utente</p>
                <p className="text-sm">Vorrei prenotare un appuntamento per domani</p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="text-xs text-muted-foreground w-16">0:18</div>
              <div className="flex-1 p-3 bg-primary/10 border border-primary/20 rounded-lg">
                <p className="text-xs font-medium text-primary mb-1">AI</p>
                <p className="text-sm">Perfetto! A che ora preferiresti venire?</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
