import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { PhoneCall, PhoneForwarded, MessageSquare, Tag } from "lucide-react";

const activeCalls = [
  {
    id: 1,
    number: "+39 345 678 9012",
    duration: "1m 23s",
    status: "active",
    transcript: [
      { speaker: "AI", text: "Buongiorno! Sono l'assistente Avix. Come posso aiutarti?" },
      { speaker: "User", text: "Vorrei prenotare un appuntamento per domani" },
      { speaker: "AI", text: "Perfetto! Che orario preferisci?" },
    ],
    aiThinking: "Elaborando richiesta di prenotazione. Verifico disponibilità calendario...",
    services: { twilio: "online", deepgram: "online", openai: "online", tts: "online" }
  },
  {
    id: 2,
    number: "+39 335 123 4567",
    duration: "3m 45s",
    status: "active",
    transcript: [
      { speaker: "AI", text: "Ciao! Sono Avix, il tuo assistente virtuale." },
      { speaker: "User", text: "Ho bisogno di informazioni sui vostri servizi" },
    ],
    aiThinking: "Ricerca informazioni nella knowledge base...",
    services: { twilio: "online", deepgram: "warning", openai: "online", tts: "online" }
  },
];

export default function LiveCalls() {
  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Chiamate in Tempo Reale</h1>
          <p className="text-muted-foreground">Monitora le conversazioni live</p>
        </div>
        <Badge variant="outline" className="text-lg px-4 py-2 border-primary text-primary animate-glow">
          <PhoneCall className="h-4 w-4 mr-2" />
          {activeCalls.length} Chiamate Attive
        </Badge>
      </div>

      <div className="grid gap-6">
        {activeCalls.map((call) => (
          <Card key={call.id} className="gradient-card border-primary/30">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center animate-pulse">
                    <PhoneCall className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{call.number}</CardTitle>
                    <p className="text-sm text-muted-foreground">Durata: {call.duration}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" className="border-warning text-warning hover:bg-warning/10">
                    <PhoneForwarded className="h-4 w-4 mr-2" />
                    Trasferisci
                  </Button>
                  <Button size="sm" variant="outline" className="border-info text-info hover:bg-info/10">
                    <MessageSquare className="h-4 w-4 mr-2" />
                    WhatsApp
                  </Button>
                  <Button size="sm" variant="outline">
                    <Tag className="h-4 w-4 mr-2" />
                    Tag
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Services Status */}
              <div className="flex items-center gap-4 p-3 bg-muted/30 rounded-lg">
                <div className="flex items-center gap-2">
                  <div className={`h-2 w-2 rounded-full ${call.services.twilio === 'online' ? 'bg-success' : 'bg-destructive'}`} />
                  <span className="text-xs">Twilio</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className={`h-2 w-2 rounded-full ${call.services.deepgram === 'online' ? 'bg-success' : 'bg-warning'}`} />
                  <span className="text-xs">Deepgram</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className={`h-2 w-2 rounded-full ${call.services.openai === 'online' ? 'bg-success' : 'bg-destructive'}`} />
                  <span className="text-xs">OpenAI</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className={`h-2 w-2 rounded-full ${call.services.tts === 'online' ? 'bg-success' : 'bg-destructive'}`} />
                  <span className="text-xs">TTS</span>
                </div>
              </div>

              {/* Transcript */}
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {call.transcript.map((msg, idx) => (
                  <div key={idx} className={`flex ${msg.speaker === 'AI' ? 'justify-start' : 'justify-end'}`}>
                    <div className={`max-w-[70%] rounded-lg p-3 ${
                      msg.speaker === 'AI' 
                        ? 'bg-primary/10 border border-primary/20' 
                        : 'bg-secondary/10 border border-secondary/20'
                    }`}>
                      <p className="text-xs font-medium mb-1 text-muted-foreground">{msg.speaker}</p>
                      <p className="text-sm">{msg.text}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* AI Thinking */}
              <div className="p-3 bg-accent/20 border border-accent rounded-lg">
                <p className="text-xs font-medium text-accent mb-1">🤖 AI sta elaborando...</p>
                <p className="text-sm text-muted-foreground italic">{call.aiThinking}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {activeCalls.length === 0 && (
        <Card className="gradient-card border-border">
          <CardContent className="py-16 text-center">
            <PhoneCall className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-xl font-semibold mb-2">Nessuna Chiamata Attiva</h3>
            <p className="text-muted-foreground">Le chiamate in corso appariranno qui</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
