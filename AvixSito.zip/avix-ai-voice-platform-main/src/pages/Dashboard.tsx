import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Phone, Clock, TrendingUp, Users, Activity, CheckCircle2, AlertCircle } from "lucide-react";
import { LineChart, Line, PieChart, Pie, Cell, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend } from "recharts";

const dailyData = [
  { time: "00:00", chiamate: 12 },
  { time: "04:00", chiamate: 8 },
  { time: "08:00", chiamate: 45 },
  { time: "12:00", chiamate: 67 },
  { time: "16:00", chiamate: 89 },
  { time: "20:00", chiamate: 34 },
];

const aiVsHuman = [
  { name: "AI Gestite", value: 85 },
  { name: "Trasferite", value: 15 },
];

const COLORS = ["hsl(190 100% 50%)", "hsl(270 80% 65%)"];

const recentEvents = [
  { id: 1, type: "call", message: "Nuova chiamata da +39 345 678 9012", time: "2 min fa", status: "success" },
  { id: 2, type: "transfer", message: "Chiamata trasferita a operatore", time: "5 min fa", status: "warning" },
  { id: 3, type: "resolved", message: "Appuntamento prenotato con successo", time: "12 min fa", status: "success" },
  { id: 4, type: "error", message: "Errore nella connessione ASR", time: "18 min fa", status: "error" },
];

export default function Dashboard() {
  return (
    <div className="p-6 space-y-6 animate-fade-in">
      {/* Hero Section */}
      <div className="gradient-card rounded-2xl p-8 border border-primary/20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
        <div className="relative z-10">
          <h1 className="text-4xl font-bold mb-2">
            Benvenuto in <span className="bg-gradient-primary bg-clip-text text-transparent">Avix-AI</span>
          </h1>
          <p className="text-muted-foreground text-lg">Il tuo Assistente Vocale Intelligente 24/7</p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="gradient-card border-primary/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Chiamate Oggi</CardTitle>
            <Phone className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">342</div>
            <p className="text-xs text-success flex items-center gap-1 mt-1">
              <TrendingUp className="h-3 w-3" /> +12% vs ieri
            </p>
          </CardContent>
        </Card>

        <Card className="gradient-card border-secondary/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">% Automazione</CardTitle>
            <Activity className="h-4 w-4 text-secondary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-secondary">85%</div>
            <p className="text-xs text-muted-foreground mt-1">AI vs Operatore</p>
          </CardContent>
        </Card>

        <Card className="gradient-card border-info/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Durata Media</CardTitle>
            <Clock className="h-4 w-4 text-info" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-info">2m 34s</div>
            <p className="text-xs text-muted-foreground mt-1">Per chiamata</p>
          </CardContent>
        </Card>

        <Card className="gradient-card border-warning/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Soddisfazione</CardTitle>
            <Users className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-warning">4.8/5</div>
            <p className="text-xs text-muted-foreground mt-1">Punteggio medio</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="gradient-card border-border">
          <CardHeader>
            <CardTitle>Attività Giornaliera</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={dailyData}>
                <XAxis dataKey="time" stroke="hsl(var(--muted-foreground))" />
                <YAxis stroke="hsl(var(--muted-foreground))" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: "hsl(var(--card))", 
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px"
                  }} 
                />
                <Line type="monotone" dataKey="chiamate" stroke="hsl(190 100% 50%)" strokeWidth={2} dot={{ fill: "hsl(190 100% 50%)" }} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="gradient-card border-border">
          <CardHeader>
            <CardTitle>AI vs Operatore</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center justify-center">
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={aiVsHuman}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {aiVsHuman.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* System Status */}
      <Card className="gradient-card border-border">
        <CardHeader>
          <CardTitle>Stato Sistema</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="h-5 w-5 text-success" />
              <div>
                <p className="text-sm font-medium">AI Latenza</p>
                <p className="text-2xl font-bold text-success">45ms</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle2 className="h-5 w-5 text-success" />
              <div>
                <p className="text-sm font-medium">TTS</p>
                <p className="text-2xl font-bold text-success">120ms</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle2 className="h-5 w-5 text-success" />
              <div>
                <p className="text-sm font-medium">ASR</p>
                <p className="text-2xl font-bold text-success">98ms</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle2 className="h-5 w-5 text-success" />
              <div>
                <p className="text-sm font-medium">Uptime</p>
                <p className="text-2xl font-bold text-success">99.9%</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Events & Test Call */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="gradient-card border-border lg:col-span-2">
          <CardHeader>
            <CardTitle>Eventi Recenti</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentEvents.map((event) => (
                <div key={event.id} className="flex items-start gap-3 p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors">
                  {event.status === "success" && <CheckCircle2 className="h-5 w-5 text-success mt-0.5" />}
                  {event.status === "warning" && <AlertCircle className="h-5 w-5 text-warning mt-0.5" />}
                  {event.status === "error" && <AlertCircle className="h-5 w-5 text-destructive mt-0.5" />}
                  <div className="flex-1">
                    <p className="text-sm font-medium">{event.message}</p>
                    <p className="text-xs text-muted-foreground">{event.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="gradient-card border-primary/30 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-primary opacity-10" />
          <CardHeader className="relative z-10">
            <CardTitle>Test Veloce</CardTitle>
          </CardHeader>
          <CardContent className="relative z-10">
            <p className="text-sm text-muted-foreground mb-4">
              Prova subito una chiamata virtuale per testare le risposte dell'AI
            </p>
            <Button className="w-full bg-primary hover:bg-primary/90 glow-primary">
              <Phone className="mr-2 h-4 w-4" />
              Avvia Test
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
