import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Play, Pause, Zap, ArrowRight } from "lucide-react";

const automations = [
  {
    id: 1,
    name: "Conferma Appuntamenti",
    status: "active",
    trigger: "Nuova prenotazione",
    actions: ["Invia SMS", "Aggiungi a Calendar"],
    executions: 145,
  },
  {
    id: 2,
    name: "Follow-up Chiamate",
    status: "active",
    trigger: "Chiamata completata",
    actions: ["Invia Email", "Tagga conversazione"],
    executions: 89,
  },
  {
    id: 3,
    name: "Alert Reclami",
    status: "paused",
    trigger: "Intent: Reclamo",
    actions: ["Notifica Team", "Crea Ticket"],
    executions: 23,
  },
];

export default function Automations() {
  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Centro Automazioni</h1>
          <p className="text-muted-foreground">Workflow intelligenti per il tuo business</p>
        </div>
        <Button className="bg-primary hover:bg-primary/90">
          <Plus className="h-4 w-4 mr-2" />
          Nuova Automazione
        </Button>
      </div>

      <div className="grid gap-4">
        {automations.map((automation) => (
          <Card key={automation.id} className="gradient-card border-border hover:border-primary/50 transition-colors">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="h-12 w-12 rounded-lg bg-primary/20 flex items-center justify-center">
                    <Zap className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle>{automation.name}</CardTitle>
                    <p className="text-sm text-muted-foreground mt-1">
                      {automation.executions} esecuzioni questo mese
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge
                    variant="outline"
                    className={automation.status === "active" ? "border-success text-success" : "border-warning text-warning"}
                  >
                    {automation.status === "active" ? "Attiva" : "In Pausa"}
                  </Badge>
                  <Button size="sm" variant="outline">
                    {automation.status === "active" ? (
                      <Pause className="h-4 w-4" />
                    ) : (
                      <Play className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-3 text-sm">
                <div className="px-3 py-2 bg-info/10 border border-info/20 rounded-lg">
                  <p className="text-xs text-info font-medium">TRIGGER</p>
                  <p className="mt-1">{automation.trigger}</p>
                </div>
                <ArrowRight className="h-5 w-5 text-muted-foreground" />
                <div className="flex-1 flex gap-2">
                  {automation.actions.map((action, idx) => (
                    <div key={idx} className="px-3 py-2 bg-primary/10 border border-primary/20 rounded-lg">
                      <p className="text-xs text-primary font-medium">AZIONE {idx + 1}</p>
                      <p className="mt-1">{action}</p>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Visual Builder Preview */}
      <Card className="gradient-card border-primary/30">
        <CardHeader>
          <CardTitle>Crea Nuova Automazione</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64 bg-muted/30 rounded-lg border-2 border-dashed border-border flex items-center justify-center">
            <div className="text-center space-y-3">
              <Zap className="h-12 w-12 mx-auto text-primary" />
              <p className="text-lg font-medium">Builder Visuale</p>
              <p className="text-sm text-muted-foreground max-w-md">
                Crea automazioni potenti collegando trigger e azioni con un'interfaccia drag & drop
              </p>
              <Button className="mt-4 bg-primary hover:bg-primary/90">
                <Plus className="h-4 w-4 mr-2" />
                Inizia
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
