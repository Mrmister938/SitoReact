import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Plus, MessageSquare, CheckCircle2, Clock, AlertCircle } from "lucide-react";

const tickets = [
  { id: 1, title: "Problema con l'integrazione Twilio", status: "open", priority: "high", created: "2 ore fa" },
  { id: 2, title: "Richiesta nuova funzionalità", status: "in_progress", priority: "medium", created: "1 giorno fa" },
  { id: 3, title: "Domanda su fatturazione", status: "resolved", priority: "low", created: "3 giorni fa" },
];

const getStatusBadge = (status: string) => {
  switch (status) {
    case "open":
      return <Badge className="bg-warning/20 text-warning border-warning"><Clock className="h-3 w-3 mr-1" />Aperto</Badge>;
    case "in_progress":
      return <Badge className="bg-info/20 text-info border-info"><MessageSquare className="h-3 w-3 mr-1" />In Corso</Badge>;
    case "resolved":
      return <Badge className="bg-success/20 text-success border-success"><CheckCircle2 className="h-3 w-3 mr-1" />Risolto</Badge>;
    default:
      return <Badge>Sconosciuto</Badge>;
  }
};

const getPriorityBadge = (priority: string) => {
  switch (priority) {
    case "high":
      return <Badge variant="outline" className="border-destructive text-destructive">Alta</Badge>;
    case "medium":
      return <Badge variant="outline" className="border-warning text-warning">Media</Badge>;
    case "low":
      return <Badge variant="outline" className="border-success text-success">Bassa</Badge>;
    default:
      return <Badge variant="outline">N/A</Badge>;
  }
};

export default function Support() {
  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Centro Supporto</h1>
          <p className="text-muted-foreground">Assistenza e ticket</p>
        </div>
        <Button className="bg-primary hover:bg-primary/90">
          <Plus className="h-4 w-4 mr-2" />
          Nuovo Ticket
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Ticket List */}
        <div className="lg:col-span-2 space-y-4">
          <Card className="gradient-card border-border">
            <CardHeader>
              <CardTitle>I Tuoi Ticket</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {tickets.map((ticket) => (
                <Card key={ticket.id} className="bg-muted/30 border-border hover:border-primary/50 transition-colors cursor-pointer">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-xs text-muted-foreground">#{ticket.id}</span>
                          {getStatusBadge(ticket.status)}
                          {getPriorityBadge(ticket.priority)}
                        </div>
                        <CardTitle className="text-base">{ticket.title}</CardTitle>
                        <p className="text-xs text-muted-foreground mt-1">Creato {ticket.created}</p>
                      </div>
                      <Button size="sm" variant="ghost">Visualizza</Button>
                    </div>
                  </CardHeader>
                </Card>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Create Ticket Form */}
        <div className="space-y-4">
          <Card className="gradient-card border-primary/30">
            <CardHeader>
              <CardTitle>Crea Nuovo Ticket</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Oggetto</label>
                <Input placeholder="Descrivi il problema..." className="bg-muted/30" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Descrizione</label>
                <Textarea
                  placeholder="Fornisci più dettagli possibili..."
                  className="min-h-[120px] bg-muted/30"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Priorità</label>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" className="flex-1 border-success text-success hover:bg-success/10">
                    Bassa
                  </Button>
                  <Button size="sm" variant="outline" className="flex-1 border-warning text-warning hover:bg-warning/10">
                    Media
                  </Button>
                  <Button size="sm" variant="outline" className="flex-1 border-destructive text-destructive hover:bg-destructive/10">
                    Alta
                  </Button>
                </div>
              </div>
              <Button className="w-full bg-primary hover:bg-primary/90">
                Invia Ticket
              </Button>
            </CardContent>
          </Card>

          {/* FAQ Quick Links */}
          <Card className="gradient-card border-border">
            <CardHeader>
              <CardTitle className="text-sm">FAQ Rapide</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {[
                "Come configurare l'assistente?",
                "Problemi di connessione",
                "Gestione della fatturazione",
                "Integrazioni disponibili",
              ].map((faq, idx) => (
                <Button
                  key={idx}
                  variant="ghost"
                  className="w-full justify-start text-sm hover:bg-primary/10 hover:text-primary"
                >
                  <AlertCircle className="h-4 w-4 mr-2" />
                  {faq}
                </Button>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
