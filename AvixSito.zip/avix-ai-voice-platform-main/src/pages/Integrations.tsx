import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Calendar, Phone, Mail, MessageSquare, Send, Webhook, CheckCircle2, AlertCircle } from "lucide-react";

const integrations = [
  { 
    id: 1, 
    name: "Google Calendar", 
    icon: Calendar, 
    status: "active", 
    description: "Sincronizza appuntamenti automaticamente"
  },
  { 
    id: 2, 
    name: "Twilio Voice", 
    icon: Phone, 
    status: "active", 
    description: "Sistema telefonico cloud"
  },
  { 
    id: 3, 
    name: "SendGrid", 
    icon: Mail, 
    status: "inactive", 
    description: "Invio email transazionali"
  },
  { 
    id: 4, 
    name: "WhatsApp Business", 
    icon: MessageSquare, 
    status: "active", 
    description: "Messaggistica istantanea"
  },
  { 
    id: 5, 
    name: "Telegram Bot", 
    icon: Send, 
    status: "inactive", 
    description: "Bot per notifiche Telegram"
  },
  { 
    id: 6, 
    name: "Webhooks", 
    icon: Webhook, 
    status: "active", 
    description: "Integrazione custom via webhook"
  },
];

export default function Integrations() {
  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold">Integrazioni</h1>
        <p className="text-muted-foreground">Connetti servizi esterni con Avix-AI</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {integrations.map((integration) => {
          const Icon = integration.icon;
          const isActive = integration.status === "active";

          return (
            <Card key={integration.id} className={`gradient-card ${isActive ? 'border-primary/30' : 'border-border'}`}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`h-12 w-12 rounded-lg flex items-center justify-center ${
                      isActive ? 'bg-primary/20' : 'bg-muted/30'
                    }`}>
                      <Icon className={`h-6 w-6 ${isActive ? 'text-primary' : 'text-muted-foreground'}`} />
                    </div>
                    <div>
                      <CardTitle className="text-base">{integration.name}</CardTitle>
                      <Badge 
                        variant="outline" 
                        className={`mt-1 ${isActive ? 'border-success text-success' : 'border-muted-foreground text-muted-foreground'}`}
                      >
                        {isActive ? (
                          <>
                            <CheckCircle2 className="h-3 w-3 mr-1" />
                            Attivo
                          </>
                        ) : (
                          <>
                            <AlertCircle className="h-3 w-3 mr-1" />
                            Inattivo
                          </>
                        )}
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">{integration.description}</p>
                
                {isActive ? (
                  <>
                    <div className="space-y-2">
                      <label className="text-xs font-medium">API Key</label>
                      <Input
                        type="password"
                        defaultValue="sk_****************************"
                        className="bg-muted/30 text-xs"
                        disabled
                      />
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" className="flex-1">
                        Modifica
                      </Button>
                      <Button size="sm" variant="outline" className="flex-1 border-success text-success hover:bg-success/10">
                        Test
                      </Button>
                    </div>
                  </>
                ) : (
                  <Button size="sm" className="w-full bg-primary hover:bg-primary/90">
                    Connetti
                  </Button>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Custom Webhook */}
      <Card className="gradient-card border-border">
        <CardHeader>
          <CardTitle>Webhook Personalizzati</CardTitle>
          <p className="text-sm text-muted-foreground">Crea endpoint custom per integrazioni avanzate</p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">URL Webhook</label>
            <Input placeholder="https://tuodominio.com/webhook" className="bg-muted/30" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Secret Key</label>
            <Input type="password" placeholder="Chiave segreta per validazione" className="bg-muted/30" />
          </div>
          <div className="flex gap-2">
            <Button className="bg-primary hover:bg-primary/90">Salva Webhook</Button>
            <Button variant="outline">Test Connessione</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
