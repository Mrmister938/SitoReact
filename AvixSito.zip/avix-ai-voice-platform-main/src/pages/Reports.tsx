import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileDown, FileText, Calendar } from "lucide-react";

const reports = [
  { month: "Gennaio 2025", calls: 1234, ai: 85, satisfaction: 4.8, date: "2025-02-01" },
  { month: "Dicembre 2024", calls: 1156, ai: 82, satisfaction: 4.7, date: "2025-01-01" },
  { month: "Novembre 2024", calls: 1089, ai: 80, satisfaction: 4.6, date: "2024-12-01" },
];

export default function Reports() {
  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Report Mensili</h1>
          <p className="text-muted-foreground">Analisi dettagliate e statistiche</p>
        </div>
        <Button className="bg-primary hover:bg-primary/90">
          <FileDown className="h-4 w-4 mr-2" />
          Genera Report
        </Button>
      </div>

      <div className="grid gap-4">
        {reports.map((report, idx) => (
          <Card key={idx} className="gradient-card border-border hover:border-primary/50 transition-colors">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="h-12 w-12 rounded-lg bg-primary/20 flex items-center justify-center">
                    <FileText className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle>{report.month}</CardTitle>
                    <p className="text-sm text-muted-foreground flex items-center gap-2 mt-1">
                      <Calendar className="h-4 w-4" />
                      Generato il {report.date}
                    </p>
                  </div>
                </div>
                <Button variant="outline">
                  <FileDown className="h-4 w-4 mr-2" />
                  Download PDF
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 bg-muted/30 rounded-lg">
                  <p className="text-sm text-muted-foreground">Chiamate Totali</p>
                  <p className="text-2xl font-bold text-primary mt-1">{report.calls}</p>
                </div>
                <div className="p-4 bg-muted/30 rounded-lg">
                  <p className="text-sm text-muted-foreground">% Automazione AI</p>
                  <p className="text-2xl font-bold text-secondary mt-1">{report.ai}%</p>
                </div>
                <div className="p-4 bg-muted/30 rounded-lg">
                  <p className="text-sm text-muted-foreground">Soddisfazione</p>
                  <p className="text-2xl font-bold text-success mt-1">{report.satisfaction}/5</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Report Preview */}
      <Card className="gradient-card border-border">
        <CardHeader>
          <CardTitle>Anteprima Report</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="aspect-[8.5/11] bg-muted/30 rounded-lg border border-border p-8 overflow-hidden">
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-border pb-4">
                <div>
                  <h2 className="text-2xl font-bold">Report Mensile</h2>
                  <p className="text-sm text-muted-foreground">Avix-AI Voice Agent</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">Gennaio 2025</p>
                  <p className="text-xs text-muted-foreground">Generato: 01/02/2025</p>
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div className="p-3 bg-primary/10 border border-primary/20 rounded">
                  <p className="text-xs text-muted-foreground">Chiamate</p>
                  <p className="text-xl font-bold text-primary">1,234</p>
                </div>
                <div className="p-3 bg-success/10 border border-success/20 rounded">
                  <p className="text-xs text-muted-foreground">AI %</p>
                  <p className="text-xl font-bold text-success">85%</p>
                </div>
                <div className="p-3 bg-warning/10 border border-warning/20 rounded">
                  <p className="text-xs text-muted-foreground">Rating</p>
                  <p className="text-xl font-bold text-warning">4.8</p>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="font-semibold">Raccomandazioni AI</h3>
                <div className="space-y-1 text-sm text-muted-foreground">
                  <p>• Ottimizza le risposte per le prenotazioni (+23% di successo)</p>
                  <p>• Migliora la gestione dei reclami (-15% di soddisfazione)</p>
                  <p>• Espandi la knowledge base per supporto tecnico</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
