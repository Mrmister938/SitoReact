import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Building, CreditCard, FileText, Crown } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Account() {
  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold">Impostazioni Account</h1>
        <p className="text-muted-foreground">Gestisci il tuo profilo e fatturazione</p>
      </div>

      <Tabs defaultValue="company" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="company" className="gap-2">
            <Building className="h-4 w-4" />
            Azienda
          </TabsTrigger>
          <TabsTrigger value="billing" className="gap-2">
            <CreditCard className="h-4 w-4" />
            Fatturazione
          </TabsTrigger>
          <TabsTrigger value="invoices" className="gap-2">
            <FileText className="h-4 w-4" />
            Fatture
          </TabsTrigger>
        </TabsList>

        <TabsContent value="company" className="space-y-6 mt-6">
          <Card className="gradient-card border-border">
            <CardHeader>
              <CardTitle>Informazioni Azienda</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Nome Azienda</Label>
                  <Input defaultValue="Avix Technologies S.r.l." className="bg-muted/30" />
                </div>
                <div className="space-y-2">
                  <Label>P.IVA</Label>
                  <Input defaultValue="IT12345678901" className="bg-muted/30" />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Indirizzo</Label>
                <Input defaultValue="Via Roma 123, 20100 Milano (MI)" className="bg-muted/30" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input defaultValue="info@avix-tech.it" type="email" className="bg-muted/30" />
                </div>
                <div className="space-y-2">
                  <Label>Telefono</Label>
                  <Input defaultValue="+39 02 1234 5678" className="bg-muted/30" />
                </div>
              </div>
              <Button className="bg-primary hover:bg-primary/90">Salva Modifiche</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="billing" className="space-y-6 mt-6">
          <Card className="gradient-card border-primary/30">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Crown className="h-5 w-5 text-warning" />
                    Piano Corrente
                  </CardTitle>
                  <p className="text-sm text-muted-foreground mt-1">Enterprise Plan</p>
                </div>
                <Badge className="bg-warning/20 text-warning border-warning">Attivo</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 bg-muted/30 rounded-lg">
                  <p className="text-sm text-muted-foreground">Costo Mensile</p>
                  <p className="text-2xl font-bold text-primary mt-1">€499</p>
                </div>
                <div className="p-4 bg-muted/30 rounded-lg">
                  <p className="text-sm text-muted-foreground">Chiamate Incluse</p>
                  <p className="text-2xl font-bold text-secondary mt-1">10,000</p>
                </div>
                <div className="p-4 bg-muted/30 rounded-lg">
                  <p className="text-sm text-muted-foreground">Prossimo Rinnovo</p>
                  <p className="text-lg font-bold text-warning mt-1">15 Feb</p>
                </div>
              </div>
              <Button variant="outline" className="w-full">Cambia Piano</Button>
            </CardContent>
          </Card>

          <Card className="gradient-card border-border">
            <CardHeader>
              <CardTitle>Metodo di Pagamento</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                <div className="flex items-center gap-3">
                  <CreditCard className="h-8 w-8 text-primary" />
                  <div>
                    <p className="font-medium">•••• •••• •••• 4242</p>
                    <p className="text-sm text-muted-foreground">Scade 12/2026</p>
                  </div>
                </div>
                <Button size="sm" variant="outline">Modifica</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="invoices" className="space-y-6 mt-6">
          <Card className="gradient-card border-border">
            <CardHeader>
              <CardTitle>Cronologia Fatture</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { id: "INV-2025-001", date: "15 Gen 2025", amount: "€499", status: "paid" },
                  { id: "INV-2024-012", date: "15 Dic 2024", amount: "€499", status: "paid" },
                  { id: "INV-2024-011", date: "15 Nov 2024", amount: "€499", status: "paid" },
                ].map((invoice) => (
                  <div key={invoice.id} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="flex items-center gap-4">
                      <FileText className="h-8 w-8 text-primary" />
                      <div>
                        <p className="font-medium">{invoice.id}</p>
                        <p className="text-sm text-muted-foreground">{invoice.date}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <p className="text-lg font-bold">{invoice.amount}</p>
                      <Badge className="bg-success/20 text-success border-success">Pagata</Badge>
                      <Button size="sm" variant="outline">Download</Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
