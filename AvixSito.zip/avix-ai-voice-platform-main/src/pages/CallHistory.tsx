import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Search, Phone, Clock, Tag, Eye } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const callHistory = [
  { id: 1, date: "2025-01-15 14:23", number: "+39 345 678 9012", duration: "2m 34s", status: "ai", intent: "Prenotazione", tags: ["Appuntamento", "Successo"] },
  { id: 2, date: "2025-01-15 13:45", number: "+39 335 123 4567", duration: "1m 12s", status: "transferred", intent: "Reclamo", tags: ["Problematica", "Trasferita"] },
  { id: 3, date: "2025-01-15 12:10", number: "+39 320 987 6543", duration: "3m 45s", status: "ai", intent: "Informazioni", tags: ["Info Servizi"] },
  { id: 4, date: "2025-01-15 11:30", number: "+39 348 765 4321", duration: "1m 56s", status: "failed", intent: "N/A", tags: ["Errore"] },
  { id: 5, date: "2025-01-15 10:15", number: "+39 333 222 1111", duration: "4m 20s", status: "ai", intent: "Cancellazione", tags: ["Gestione", "Completata"] },
];

export default function CallHistory() {
  const [searchQuery, setSearchQuery] = useState("");

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "ai":
        return <Badge className="bg-success/20 text-success border-success">AI Gestita</Badge>;
      case "transferred":
        return <Badge className="bg-warning/20 text-warning border-warning">Trasferita</Badge>;
      case "failed":
        return <Badge className="bg-destructive/20 text-destructive border-destructive">Fallita</Badge>;
      default:
        return <Badge>Sconosciuto</Badge>;
    }
  };

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Storico Chiamate</h1>
          <p className="text-muted-foreground">Visualizza e analizza tutte le conversazioni</p>
        </div>
      </div>

      <Card className="gradient-card border-border">
        <CardHeader>
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Cerca per numero, intent o tag..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-muted/30"
              />
            </div>
            <Button variant="outline">
              <Tag className="h-4 w-4 mr-2" />
              Filtra
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Data/Ora</TableHead>
                <TableHead>Numero</TableHead>
                <TableHead>Durata</TableHead>
                <TableHead>Stato</TableHead>
                <TableHead>Intent</TableHead>
                <TableHead>Tags</TableHead>
                <TableHead className="text-right">Azioni</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {callHistory.map((call) => (
                <TableRow key={call.id} className="hover:bg-muted/30">
                  <TableCell className="font-medium">{call.date}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-primary" />
                      {call.number}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      {call.duration}
                    </div>
                  </TableCell>
                  <TableCell>{getStatusBadge(call.status)}</TableCell>
                  <TableCell>
                    <Badge variant="outline">{call.intent}</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {call.tags.map((tag, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button size="sm" variant="ghost">
                      <Eye className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
