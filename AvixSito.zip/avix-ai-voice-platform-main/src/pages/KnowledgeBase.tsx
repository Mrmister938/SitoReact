import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Plus, FileText, Search, Sparkles } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const knowledgeItems = [
  { id: 1, title: "Come prenotare un appuntamento", category: "FAQ", content: "Per prenotare un appuntamento..." },
  { id: 2, title: "Orari di apertura", category: "Info", content: "Siamo aperti dal lunedì al venerdì..." },
  { id: 3, title: "Politica di cancellazione", category: "Politiche", content: "È possibile cancellare..." },
];

export default function KnowledgeBase() {
  const [testQuestion, setTestQuestion] = useState("");

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Knowledge Base AI</h1>
          <p className="text-muted-foreground">Gestisci le informazioni dell'assistente</p>
        </div>
        <Button className="bg-primary hover:bg-primary/90">
          <Plus className="h-4 w-4 mr-2" />
          Nuovo Contenuto
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Knowledge List */}
        <div className="lg:col-span-2 space-y-4">
          <Card className="gradient-card border-border">
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Cerca nella knowledge base..." className="pl-10 bg-muted/30" />
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {knowledgeItems.map((item) => (
                <Card key={item.id} className="bg-muted/30 border-border hover:border-primary/50 transition-colors cursor-pointer">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3">
                        <FileText className="h-5 w-5 text-primary mt-1" />
                        <div>
                          <CardTitle className="text-sm">{item.title}</CardTitle>
                          <p className="text-xs text-muted-foreground mt-1">{item.category}</p>
                        </div>
                      </div>
                      <Button size="sm" variant="ghost">Modifica</Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground line-clamp-2">{item.content}</p>
                  </CardContent>
                </Card>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* AI Test Panel */}
        <div className="space-y-4">
          <Card className="gradient-card border-primary/30 sticky top-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-primary" />
                Test AI
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Prova una domanda</label>
                <Textarea
                  placeholder="Es: Quali sono gli orari di apertura?"
                  value={testQuestion}
                  onChange={(e) => setTestQuestion(e.target.value)}
                  className="min-h-[100px] bg-muted/30"
                />
              </div>
              <Button className="w-full bg-primary hover:bg-primary/90">
                Testa Risposta AI
              </Button>

              {testQuestion && (
                <div className="p-4 bg-primary/10 border border-primary/20 rounded-lg space-y-2">
                  <p className="text-xs font-medium text-primary">Risposta AI:</p>
                  <p className="text-sm">
                    Siamo aperti dal lunedì al venerdì dalle 9:00 alle 18:00. 
                    Il sabato dalle 9:00 alle 13:00. Domenica chiusi.
                  </p>
                  <div className="pt-2 border-t border-primary/20">
                    <p className="text-xs text-muted-foreground">
                      Fonte: Knowledge Base → Info → Orari di apertura
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Editor Section */}
      <Card className="gradient-card border-border">
        <CardHeader>
          <CardTitle>Nuovo Contenuto</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="faq" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="faq">FAQ</TabsTrigger>
              <TabsTrigger value="document">Documento</TabsTrigger>
              <TabsTrigger value="section">Sezione</TabsTrigger>
            </TabsList>
            <TabsContent value="faq" className="space-y-4 mt-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Titolo</label>
                <Input placeholder="Es: Come posso cancellare un appuntamento?" className="bg-muted/30" />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Contenuto</label>
                <Textarea placeholder="Inserisci la risposta..." className="min-h-[150px] bg-muted/30" />
              </div>
              <div className="flex gap-2">
                <Button className="bg-primary hover:bg-primary/90">Salva</Button>
                <Button variant="outline">Anteprima</Button>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
